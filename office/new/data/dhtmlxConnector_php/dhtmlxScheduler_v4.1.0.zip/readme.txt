dhtmlxScheduler v.4.1.0 Stardard

This software is covered by GPL license. You also can obtain Commercial or Enterprise license to use it in non-GPL project - please contact sales@dhtmlx.com. Usage without proper license is prohibited.

(c) Dinamenta, UAB.


Useful links
-------------

- Online  documentation
	http://docs.dhtmlx.com/scheduler/
- Downloadable documentation
	CHM version
		http://dhtmlx.com/regular/dhtmlxScheduler_docs_chm.zip
	HTML version
		http://dhtmlx.com/regular/dhtmlxScheduler_docs_html.zip
- Support forum
	http://forum.dhtmlx.com/viewforum.php?f=6
- Skin builder
	http://dhtmlx.com/docs/products/dhtmlxScheduler/skinBuilder/index.shtml


Other editions
--------------

- MVC.Net edition
	http://scheduler-net.com
- Java edition (JSP, Struts, Spring, Grails)
	http://javaplanner.com
- Windows8 edition
	http://dhtmlx.com/download/regular/dhtmlxScheduler_windows.zip
- Scheduler for mobile devices
	http://dhtmlx.com/x/download/regular/dhtmlxScheduler_mobile.zip