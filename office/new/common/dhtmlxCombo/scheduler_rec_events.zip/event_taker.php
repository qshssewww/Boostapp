<?php

include('db_config.php');
include('SchedulerHelper.php');

if (!@$connect = mysql_connect($host, $user, $pass))
	{
	die('Error of database connecting.');
	}
	else
	{
	@mysql_select_db($db_name, $connect);
	}

$start = '2011-02-09 00:00:00';
$endd = '2011-02-29 20:00:00';

$dates = new SchedulerHelper($connect, "events_rec");
$final = $dates->get_dates($start, $endd);

echo "<pre>";
print_r($final);
echo "</pre>";


?>